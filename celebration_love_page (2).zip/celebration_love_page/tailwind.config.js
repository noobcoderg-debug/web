/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './app/**/*.{js,jsx}',
    './src/**/*.{js,jsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "var(--color-border)", /* subtle-lavender */
        input: "var(--color-input)", /* white */
        ring: "var(--color-ring)", /* romantic-pink */
        background: "var(--color-background)", /* soft-romantic-white */
        foreground: "var(--color-foreground)", /* deep-purple */
        primary: {
          DEFAULT: "var(--color-primary)", /* romantic-pink */
          foreground: "var(--color-primary-foreground)", /* white */
        },
        secondary: {
          DEFAULT: "var(--color-secondary)", /* lavender */
          foreground: "var(--color-secondary-foreground)", /* deep-purple */
        },
        destructive: {
          DEFAULT: "var(--color-destructive)", /* soft-red */
          foreground: "var(--color-destructive-foreground)", /* white */
        },
        muted: {
          DEFAULT: "var(--color-muted)", /* subtle-lavender */
          foreground: "var(--color-muted-foreground)", /* medium-purple */
        },
        accent: {
          DEFAULT: "var(--color-accent)", /* gold */
          foreground: "var(--color-accent-foreground)", /* deep-purple */
        },
        popover: {
          DEFAULT: "var(--color-popover)", /* white */
          foreground: "var(--color-popover-foreground)", /* deep-purple */
        },
        card: {
          DEFAULT: "var(--color-card)", /* white */
          foreground: "var(--color-card-foreground)", /* deep-purple */
        },
        success: {
          DEFAULT: "var(--color-success)", /* mint */
          foreground: "var(--color-success-foreground)", /* deep-purple */
        },
        warning: {
          DEFAULT: "var(--color-warning)", /* coral */
          foreground: "var(--color-warning-foreground)", /* deep-purple */
        },
        error: {
          DEFAULT: "var(--color-error)", /* soft-red */
          foreground: "var(--color-error-foreground)", /* white */
        },
        surface: {
          DEFAULT: "var(--color-surface)", /* subtle-lavender */
          foreground: "var(--color-surface-foreground)", /* deep-purple */
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        heading: ['Poppins', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        accent: ['Dancing Script', 'cursive'],
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in": {
          "0%": { opacity: "0", transform: "translateY(10px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "bounce-in": {
          "0%": { transform: "scale(0.3)", opacity: "0" },
          "50%": { transform: "scale(1.05)" },
          "70%": { transform: "scale(0.9)" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
        "confetti": {
          "0%": { transform: "translateY(-100vh) rotate(0deg)", opacity: "1" },
          "100%": { transform: "translateY(100vh) rotate(720deg)", opacity: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.25s ease-in-out",
        "bounce-in": "bounce-in 0.6s ease-out",
        "confetti": "confetti 3s linear infinite",
      },
      boxShadow: {
        'gift-card': '0 4px 12px rgba(255, 107, 157, 0.15)',
        'cta-active': '0 2px 8px rgba(255, 107, 157, 0.25)',
      },
      transitionDuration: {
        '150': '150ms',
        '200': '200ms',
        '250': '250ms',
      },
      transitionTimingFunction: {
        'ease-in-out': 'ease-in-out',
      },
    },
  },
  plugins: [
    require("tailwindcss-animate"),
  ],
}