import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import HeroSection from './components/HeroSection';
import PersonalMessage from './components/PersonalMessage';
import AchievementCelebration from './components/AchievementCelebration';
import PhotoIntegration from './components/PhotoIntegration';
import GiftsShowcase from './components/GiftsShowcase';
import PromoCodeSection from './components/PromoCodeSection';
import RelationshipMilestone from './components/RelationshipMilestone';
import LoveDeclaration from './components/LoveDeclaration';

const LandingPage = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  // Load saved language preference on component mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem('celebrationLanguage');
    if (savedLanguage && ['en', 'hi', 'fil']?.includes(savedLanguage)) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  // Handle language change and save to localStorage
  const handleLanguageChange = (language) => {
    setCurrentLanguage(language);
    localStorage.setItem('celebrationLanguage', language);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Animated Congratulations */}
      <HeroSection 
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
      />
      {/* Personal Romantic Message */}
      <PersonalMessage currentLanguage={currentLanguage} />
      {/* Achievement Celebration with Progress Bars */}
      <AchievementCelebration currentLanguage={currentLanguage} />
      {/* Photo Integration with Monthsary Picture */}
      <PhotoIntegration currentLanguage={currentLanguage} />
      {/* Interactive Gifts Showcase */}
      <GiftsShowcase currentLanguage={currentLanguage} />
      {/* Promo Code Copy-to-Clipboard Section */}
      <PromoCodeSection currentLanguage={currentLanguage} />
      {/* Relationship Milestone with Countdown */}
      <RelationshipMilestone currentLanguage={currentLanguage} />
      {/* Love Declaration with Emotional Messaging */}
      <LoveDeclaration currentLanguage={currentLanguage} />
      {/* Footer with Dynamic Copyright */}
      <motion.footer
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="bg-gray-900 text-white py-12 px-6"
      >
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-6">
            <h3 className="text-2xl font-bold font-accent text-pink-300 mb-2">
              Made with Endless Love
            </h3>
            <p className="text-gray-400">
              A digital celebration of your amazing achievement and our beautiful journey together
            </p>
          </div>
          
          <div className="border-t border-gray-700 pt-6">
            <p className="text-gray-500">
              © {new Date()?.getFullYear()} - Created with ❤️ for the most amazing person in my life
            </p>
          </div>
        </div>
      </motion.footer>
    </div>
  );
};

export default LandingPage;