import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const AchievementCelebration = ({ currentLanguage }) => {
  const [progress, setProgress] = useState(0);
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setProgress(100); // 3rd position = 100% achievement
      setShowStats(true);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const content = {
    en: {
      title: "Your Academic Excellence Shines Bright",
      subtitle: "3rd Position Achievement Breakdown",
      stats: [
        { label: "Academic Rank", value: "3rd", icon: "Trophy" },
        { label: "Excellence Level", value: "Outstanding", icon: "Star" },
        { label: "Dedication Score", value: "100%", icon: "Target" },
        { label: "Pride Level", value: "Infinite", icon: "Heart" }
      ],
      achievements: [
        "Consistent hard work and dedication",
        "Outstanding academic performance",
        "Inspiring others with your success",
        "Making dreams come true"
      ],
      message: "Your achievement represents months of dedication, countless hours of study, and unwavering determination. You've proven that with passion and persistence, anything is possible!"
    },
    hi: {
      title: "आपकी शैक्षणिक उत्कृष्टता चमक रही है",
      subtitle: "तीसरी स्थिति की उपलब्धि का विवरण",
      stats: [
        { label: "शैक्षणिक रैंक", value: "तीसरा", icon: "Trophy" },
        { label: "उत्कृष्टता स्तर", value: "बेहतरीन", icon: "Star" },
        { label: "समर्पण स्कोर", value: "100%", icon: "Target" },
        { label: "गर्व का स्तर", value: "अनंत", icon: "Heart" }
      ],
      achievements: [
        "निरंतर कड़ी मेहनत और समर्पण",
        "उत्कृष्ट शैक्षणिक प्रदर्शन",
        "अपनी सफलता से दूसरों को प्रेरणा देना",
        "सपनों को साकार करना"
      ],
      message: "आपकी यह उपलब्धि महीनों के समर्पण, अनगिनत घंटों की पढ़ाई, और अटूट दृढ़ता का प्रतिनिधित्व करती है। आपने साबित कर दिया है कि जुनून और दृढ़ता के साथ कुछ भी संभव है!"
    },
    fil: {
      title: "Ang Inyong Academic Excellence ay Nagniningning",
      subtitle: "3rd Position Achievement Breakdown",
      stats: [
        { label: "Academic Rank", value: "Ikatlo", icon: "Trophy" },
        { label: "Excellence Level", value: "Napakagaling", icon: "Star" },
        { label: "Dedication Score", value: "100%", icon: "Target" },
        { label: "Pride Level", value: "Walang Hanggan", icon: "Heart" }
      ],
      achievements: [
        "Tuloy-tuloy na sipag at dedikasyon",
        "Napakagaling na academic performance",
        "Naging inspirasyon sa iba sa inyong tagumpay",
        "Natupad ang mga pangarap"
      ],
      message: "Ang inyong tagumpay ay kumakatawan sa mga buwan ng dedikasyon, walang bilang na oras ng pag-aaral, at walang sawang determinasyon. Napatunayan ninyo na sa pamamagitan ng passion at persistence, lahat ay posible!"
    }
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-yellow-50 via-orange-50 to-red-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            {content?.[currentLanguage]?.subtitle}
          </p>
          
          {/* Progress Bar */}
          <div className="max-w-md mx-auto">
            <div className="bg-white rounded-full p-2 shadow-lg">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: showStats ? `${progress}%` : 0 }}
                transition={{ duration: 2, ease: "easeOut" }}
                className="h-4 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-full relative overflow-hidden"
              >
                <motion.div
                  animate={{ x: ['-100%', '100%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                />
              </motion.div>
            </div>
            <p className="text-sm text-gray-600 mt-2">Achievement Progress: {progress}%</p>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {content?.[currentLanguage]?.stats?.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 text-center relative overflow-hidden"
            >
              {/* Background Gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-100 to-orange-100 opacity-50"></div>
              
              <div className="relative z-10">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full mb-4 shadow-lg">
                  <Icon name={stat?.icon} size={32} color="white" />
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
                  {stat?.value}
                </h3>
                <p className="text-gray-600 font-medium">
                  {stat?.label}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Achievements List */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 mb-12"
        >
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">
            What This Achievement Represents
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {content?.[currentLanguage]?.achievements?.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 p-4 rounded-xl bg-gradient-to-r from-yellow-50 to-orange-50 hover:from-yellow-100 hover:to-orange-100 transition-all duration-300"
              >
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                  <Icon name="Check" size={20} color="white" />
                </div>
                <p className="text-gray-700 font-medium">{achievement}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Inspirational Message */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-4 left-4">
              <Icon name="Star" size={48} />
            </div>
            <div className="absolute top-8 right-8">
              <Icon name="Trophy" size={40} />
            </div>
            <div className="absolute bottom-4 left-8">
              <Icon name="Heart" size={36} />
            </div>
            <div className="absolute bottom-8 right-4">
              <Icon name="Sparkles" size={44} />
            </div>
          </div>

          <div className="relative z-10">
            <p className="text-lg md:text-xl leading-relaxed font-medium">
              {content?.[currentLanguage]?.message}
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AchievementCelebration;