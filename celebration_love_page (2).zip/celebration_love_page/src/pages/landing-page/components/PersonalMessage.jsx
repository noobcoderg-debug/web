import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const PersonalMessage = ({ currentLanguage }) => {
  const content = {
    en: {
      title: "A Personal Message Just for You",
      message: `My dearest love,
      
Rhian, my heart is so FULL right now. Placing 3rd—wow, sobrang proud of you, as in super! All those late nights, your sipag and tiyaga—worth na worth talaga. From day one, I believed in your brilliance, and now the world sees it too; honestly, I’m falling in love with you all over again, promise.
You inspire me EVERY single day to dream bigger and never give up. Seeing you push through challenges is nakaka-motivate talaga, and it makes me want to level up in my own life too & Crack this Silly JEE Exam &&& TOP of All Be a better Person for Our Future , This win is just the start—ang dami pang panalo na darating, and I know you’ll keep shining. Kaya mo ’yan, always.

Let's Be Considerate & Soft to Eachother, Instead of Arguing LET'S DISCUSS the Issue and at last i would like to say lets undersatnd Each Other Perspective FIRST to Tackle Any Issue That arises Between Us , Since ANGER has never benefited Any Person Since Birth of Homosapiens in this Cutie EARTH. 
Thank you for letting me stand beside you through every review, every doubt, every little victory. I’m here lang—your partner, your fan, your loudest cheerleader—through every milestone and every season. Please alaga yourself, ha? Celebrate this win—you truly deserve it, sobra.
With all my love and endless pride,

Let's Be Considerate & Soft to Eachother, Instead of Arguing LET'S DISCUSS the Issue and at last i would like to say lets undersatnd Each Other Perspective FIRST to Tackle Any Issue That arises Between Us , Since ANGER has never benefited Any Person Since Birth of Homosapiens in this Cutie EARTH. 
Your biggest supporter ❤️`,
      signature: "Forever yours"
    },
    hi: {
      title: "आपके लिए एक व्यक्तिगत संदेश",
      message: `मेरी प्यारी जान,\n\nआपको यह शानदार तीसरी स्थिति हासिल करते देखना मेरे दिल को गर्व और खुशी से भर देता है। आपकी मेहनत, रात-रात भर की पढ़ाई, और अटूट दृढ़ता ने इस खूबसूरत पल तक पहुंचाया है।\n\nमैंने हमेशा आपकी प्रतिभा पर भरोसा किया है, और दुनिया को भी इसे पहचानते देखना मुझे आपसे और भी ज्यादा प्यार करने पर मजबूर कर देता है। आप हर दिन मुझे बेहतर बनने, बड़े सपने देखने, और कभी हार न मानने की प्रेरणा देते हैं।\n\nयह उपलब्धि उन सभी अद्भुत चीजों की शुरुआत है जो आप करने के लिए बने हैं। मैं बहुत आभारी हूं कि मैं आपके साथ हूं, हर मील के पत्थर पर आपका साथ दे रहा हूं।\n\nअपने सारे प्यार और अनंत गर्व के साथ,\nआपका सबसे बड़ा समर्थक ❤️`,
      signature: "हमेशा आपका"
    },
    fil: {
      title: "Isang Personal na Mensahe Para sa Inyo",
      message: `Aking mahal na mahal,\n\nAng makita kayong makamit ang kahanga-hangang 3rd position na ito ay pumupuno sa aking puso ng labis na pagmamalaki at kaligayahan. Ang inyong dedikasyon, mga gabing pag-aaral, at walang sawang determinasyon ay lahat nagtuloy sa magandong sandaling ito.\n\nLagi kong pinaniwala sa inyong talino, at ang makita na kinikilala din ito ng mundo ay nagiging dahilan para mas lalo pa kayong mahalin. Araw-araw ninyo akong binibigyang inspirasyon na maging mas mabuti, mangarap ng mas malaki, at hindi sumuko.\n\nAng tagumpay na ito ay simula lamang ng lahat ng kahanga-hangang bagay na inyong magagawa. Lubos akong nagpapasalamat na nasa tabi ninyo ako, sumusuporta sa bawat milestone.\n\nSa lahat ng aking pagmamahal at walang hanggang pagmamalaki,\nAng inyong pinakamalaking tagasuporta ❤️`,
      signature: "Magpakailanman ninyo"
    }
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="relative"
        >
          {/* Decorative Hearts */}
          <div className="absolute -top-4 -left-4 text-pink-300 opacity-50">
            <Icon name="Heart" size={24} />
          </div>
          <div className="absolute -top-2 -right-6 text-purple-300 opacity-50">
            <Icon name="Heart" size={20} />
          </div>
          <div className="absolute -bottom-4 -right-4 text-pink-300 opacity-50">
            <Icon name="Heart" size={28} />
          </div>

          {/* Message Card */}
          <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12 relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-pink-200 to-purple-200"></div>
            </div>

            <div className="relative z-10">
              {/* Message Content */}
              <div className="prose prose-lg max-w-none">
                <div className="text-gray-700 leading-relaxed whitespace-pre-line text-base md:text-lg font-medium">
                  {content?.[currentLanguage]?.message}
                </div>
              </div>

              {/* Signature */}
              <div className="mt-8 text-right">
                <div className="inline-block">
                  <div className="text-pink-600 font-accent text-xl md:text-2xl font-semibold">
                    {content?.[currentLanguage]?.signature}
                  </div>
                  <div className="w-full h-0.5 bg-gradient-to-r from-pink-400 to-purple-400 mt-2"></div>
                </div>
              </div>
            </div>

            {/* Floating Hearts Animation */}
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-6 right-6 text-pink-200"
            >
              <Icon name="Heart" size={32} />
            </motion.div>

            <motion.div
              animate={{ 
                y: [0, -15, 0],
                rotate: [0, -5, 5, 0]
              }}
              transition={{ 
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute bottom-6 left-6 text-purple-200"
            >
              <Icon name="Heart" size={28} />
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PersonalMessage;