import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const PhotoIntegration = ({ currentLanguage }) => {
  const [isZoomed, setIsZoomed] = useState(false);

  const content = {
    en: {
      title: "Our Beautiful Journey Together",
      subtitle: "Celebrating our monthsary and your amazing achievement",
      caption: "This moment captures not just our love, but also the pride I feel watching you succeed",
      dateLabel: "Our Special Monthsary",
      achievementLabel: "Your Achievement Day"
    },
    hi: {
      title: "हमारी खूबसूरत यात्रा एक साथ",
      subtitle: "हमारी मासिक वर्षगांठ और आपकी अद्भुत उपलब्धि का जश्न",
      caption: "यह पल न केवल हमारे प्यार को दर्शाता है, बल्कि आपकी सफलता देखकर मुझे जो गर्व महसूस होता है उसे भी",
      dateLabel: "हमारी विशेष मासिक वर्षगांठ",
      achievementLabel: "आपकी उपलब्धि का दिन"
    },
    fil: {
      title: "Ang Aming Magandang Paglalakbay Nang Sama-sama",
      subtitle: "Pagdiriwang ng aming monthsary at ng inyong kahanga-hangang tagumpay",
      caption: "Ang sandaling ito ay hindi lamang nagpapakita ng aming pagmamahal, kundi pati na rin ang pagmamalaki na nararamdaman ko sa inyong tagumpay",
      dateLabel: "Ang Aming Espesyal na Monthsary",
      achievementLabel: "Ang Araw ng Inyong Tagumpay"
    }
  };

  // Mock monthsary date (using current date for demo)
  const monthsaryDate = new Date();
  const achievementDate = new Date(2025, 8, 28); // August 28, 2025

  const formatDate = (date) => {
    return date?.toLocaleDateString(currentLanguage === 'hi' ? 'hi-IN' : currentLanguage === 'fil' ? 'fil-PH' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-pink-50 via-rose-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {content?.[currentLanguage]?.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Photo Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            {/* Heart-shaped Frame Container */}
            <div className="relative max-w-md mx-auto">
              {/* Floating Hearts */}
              <motion.div
                animate={{ 
                  y: [0, -10, 0],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute -top-6 -left-6 text-pink-400 z-10"
              >
                <Icon name="Heart" size={32} />
              </motion.div>

              <motion.div
                animate={{ 
                  y: [0, -15, 0],
                  rotate: [0, -5, 5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1
                }}
                className="absolute -top-4 -right-8 text-purple-400 z-10"
              >
                <Icon name="Heart" size={28} />
              </motion.div>

              <motion.div
                animate={{ 
                  y: [0, -8, 0],
                  rotate: [0, 8, -8, 0]
                }}
                transition={{ 
                  duration: 5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 2
                }}
                className="absolute -bottom-6 -right-4 text-rose-400 z-10"
              >
                <Icon name="Heart" size={24} />
              </motion.div>

              {/* Main Photo Container */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="relative overflow-hidden rounded-3xl shadow-2xl cursor-pointer"
                onClick={() => setIsZoomed(!isZoomed)}
              >
                {/* Heart-shaped overlay effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-pink-200/20 to-purple-200/20 z-10 rounded-3xl"></div>
                
                {/* Photo */}
                <div className="aspect-square overflow-hidden rounded-3xl">
                  <Image
                    src="https://i.postimg.cc/LscLfRSP/image-1.png"
                    alt="Our beautiful monthsary moment together"
                    className={`w-full h-full object-cover transition-transform duration-500 ${
                      isZoomed ? 'scale-110' : 'scale-100'
                    }`}
                  />
                </div>

                {/* Photo Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent rounded-3xl"></div>
                
                {/* Zoom Icon */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <Icon name={isZoomed ? "ZoomOut" : "ZoomIn"} size={20} />
                </div>
              </motion.div>

              {/* Decorative Border */}
              <div className="absolute inset-0 rounded-3xl border-4 border-gradient-to-r from-pink-300 to-purple-300 opacity-50 -z-10 transform scale-105"></div>
            </div>

            {/* Photo Caption */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              viewport={{ once: true }}
              className="text-center text-gray-600 mt-6 italic font-medium max-w-md mx-auto"
            >
              {content?.[currentLanguage]?.caption}
            </motion.p>
          </motion.div>

          {/* Details Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Monthsary Date Card */}
            <div className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-pink-200 to-purple-200 rounded-bl-full opacity-50"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
                    <Icon name="Calendar" size={24} color="white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800">
                    {content?.[currentLanguage]?.dateLabel}
                  </h3>
                </div>
                <p className="text-2xl font-bold text-pink-600 mb-2">
                  {formatDate(monthsaryDate)}
                </p>
                <p className="text-gray-600">
                  Every month with you is a celebration of our love
                </p>
              </div>
            </div>

            {/* Achievement Date Card */}
            <div className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-yellow-200 to-orange-200 rounded-bl-full opacity-50"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                    <Icon name="Trophy" size={24} color="white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800">
                    {content?.[currentLanguage]?.achievementLabel}
                  </h3>
                </div>
                <p className="text-2xl font-bold text-orange-600 mb-2">
                  {formatDate(achievementDate)}
                </p>
                <p className="text-gray-600">
                  The day you made us both proud with your 3rd position
                </p>
              </div>
            </div>

            {/* Love Stats */}
            <div className="bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl p-6 text-white relative overflow-hidden">
              <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Icon name="Heart" size={24} />
                  Our Love Journey
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">∞</div>
                    <div className="text-sm opacity-90">Love Level</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">100%</div>
                    <div className="text-sm opacity-90">Support</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">3rd</div>
                    <div className="text-sm opacity-90">Your Rank</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">1st</div>
                    <div className="text-sm opacity-90">In My Heart</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default PhotoIntegration;