import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const GiftsShowcase = ({ currentLanguage }) => {
  const [revealedGifts, setRevealedGifts] = useState([]);

  const content = {
    en: {
      title: "Special Gifts Just for You",
      subtitle: "Because you deserve the world and more",
      revealText: "Click to reveal your surprise",
      gifts: [
        {
          id: 'netflix',
          name: 'Netflix Premium',
          description: 'Unlimited movies and shows for our cozy nights together',
          personalMessage: 'For all those times we said "let\'s watch something" and spent an hour deciding. Now we have endless options for our movie dates!',
          value: '₱449/month',
          duration: 'Forever',
          features: ['1080p HD', 'Multiple Screens', 'No Ads'],
          color: 'from-red-500 to-red-600',
          icon: 'Play',
          image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400&h=300&fit=crop'
        },
        {
          id: 'spotify',
          name: 'Spotify Premium',
          description: 'Our favorite songs, anytime, anywhere',
          personalMessage: 'Remember our playlist "Songs that remind me of you"? Now you can listen to it and discover new music without any interruptions!',
          value: '₱90/month',
          duration: '4 Months',
          features: ['Ad-free Music', 'Offline Downloads', 'High Quality Audio', 'Unlimited Skips'],
          color: 'from-green-500 to-green-600',
          icon: 'Music',
          image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop'
        },
        {
          id: 'MUBI',
          name: 'MUBI Premium',
          description: 'Magic, Thriller, and childhood memories',
          personalMessage: 'For the Big Brain inside You, Need to Be Feed New Knowledge Everyday',
          value: '₱240/month',
          duration: '3 months',
          features: ['Documentary', 'Marvel & Oscar Movies', '4K Streaming', 'Multiple Profiles'],
          color: 'from-blue-500 to-purple-600',
          icon: 'Star',
          image: 'https://images.unsplash.com/photo-1489599162163-3fb4e0c30b0b?w=400&h=300&fit=crop'
        }
      ]
    },
    hi: {
      title: "आपके लिए विशेष उपहार",
      subtitle: "क्योंकि आप दुनिया और उससे भी ज्यादा के हकदार हैं",
      revealText: "अपना सरप्राइज देखने के लिए क्लिक करें",
      gifts: [
        {
          id: 'netflix',
          name: 'Netflix Premium',
          description: 'हमारी आरामदायक रातों के लिए असीमित फिल्में और शो',
          personalMessage: 'उन सभी बार के लिए जब हमने कहा "कुछ देखते हैं" और फिर एक घंटा सोचते रहे कि क्या देखें। अब हमारे पास मूवी डेट्स के लिए अनंत विकल्प हैं!',
          value: '$15.99/माह',
          duration: '6 महीने',
          features: ['4K Ultra HD', 'Multiple Screens', 'Download & Watch Offline', 'No Ads'],
          color: 'from-red-500 to-red-600',
          icon: 'Play',
          image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400&h=300&fit=crop'
        },
        {
          id: 'spotify',
          name: 'Spotify Premium',
          description: 'हमारे पसंदीदा गाने, कभी भी, कहीं भी',
          personalMessage: 'याद है हमारी प्लेलिस्ट "Songs that remind me of you"? अब आप इसे सुन सकते हैं और बिना किसी रुकावट के नया संगीत खोज सकते हैं!',
          value: '$9.99/माह',
          duration: '12 महीने',
          features: ['Ad-free Music', 'Offline Downloads', 'High Quality Audio', 'Unlimited Skips'],
          color: 'from-green-500 to-green-600',
          icon: 'Music',
          image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop'
        },
        {
          id: 'disney',
          name: 'Disney+ Premium',
          description: 'जादू, रोमांच, और बचपन की यादें',
          personalMessage: 'आप में छुपी उस Disney princess के लिए जो अभी भी एनिमेटेड फिल्मों को देखकर खुश हो जाती है। आइए एक साथ अपना बचपन फिर से जीते हैं!',
          value: '$7.99/माह',
          duration: '12 महीने',
          features: ['Disney Classics', 'Marvel & Star Wars', '4K Streaming', 'Multiple Profiles'],
          color: 'from-blue-500 to-purple-600',
          icon: 'Star',
          image: 'https://images.unsplash.com/photo-1489599162163-3fb4e0c30b0b?w=400&h=300&fit=crop'
        }
      ]
    },
    fil: {
      title: "Mga Espesyal na Regalo Para sa Inyo",
      subtitle: "Dahil karapat-dapat kayo sa mundo at higit pa",
      revealText: "I-click para makita ang inyong surprise",
      gifts: [
        {
          id: 'netflix',
          name: 'Netflix Premium',
          description: 'Walang hanggang movies at shows para sa aming mga cozy nights',
          personalMessage: 'Para sa lahat ng mga beses na sinabi natin "manood tayo ng something" at nag-isang oras pa bago nakapag-decide. Ngayon may endless options na tayo para sa movie dates!',
          value: '$15.99/buwan',
          duration: '6 buwan',
          features: ['4K Ultra HD', 'Multiple Screens', 'Download & Watch Offline', 'No Ads'],
          color: 'from-red-500 to-red-600',
          icon: 'Play',
          image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400&h=300&fit=crop'
        },
        {
          id: 'spotify',
          name: 'Spotify Premium',
          description: 'Ang aming mga paboritong kanta, kahit saan, kahit kailan',
          personalMessage: 'Naaalala ninyo ba ang playlist natin na "Songs that remind me of you"? Ngayon pwede na ninyong pakinggan ito at mag-discover ng bagong music nang walang interruption!',
          value: '$9.99/buwan',
          duration: '12 buwan',
          features: ['Ad-free Music', 'Offline Downloads', 'High Quality Audio', 'Unlimited Skips'],
          color: 'from-green-500 to-green-600',
          icon: 'Music',
          image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=300&fit=crop'
        },
        {
          id: 'MUBI',
          name: 'MUBI+ Premium',
          description: 'Magic, adventure, at mga childhood memories',
          personalMessage: 'Para sa Malaking Utak sa loob Mo, Kailangang Magpakain ng Bagong Kaalaman Araw-araw',
          value: '$7.99/buwan',
          duration: '12 buwan',
          features: ['Disney Classics', 'Marvel & Star Wars', '4K Streaming', 'Multiple Profiles'],
          color: 'from-blue-500 to-purple-600',
          icon: 'Star',
          image: 'https://images.unsplash.com/photo-1489599162163-3fb4e0c30b0b?w=400&h=300&fit=crop'
        }
      ]
    }
  };

  const handleGiftReveal = (giftId) => {
    if (!revealedGifts?.includes(giftId)) {
      setRevealedGifts([...revealedGifts, giftId]);
    }
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            {content?.[currentLanguage]?.subtitle}
          </p>
          
          {/* Gift Counter */}
          <div className="inline-flex items-center gap-2 bg-white rounded-full px-6 py-3 shadow-lg">
            <Icon name="Gift" size={20} className="text-purple-500" />
            <span className="font-semibold text-gray-700">
              {revealedGifts?.length} of {content?.[currentLanguage]?.gifts?.length} gifts revealed
            </span>
          </div>
        </motion.div>

        {/* Gifts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content?.[currentLanguage]?.gifts?.map((gift, index) => {
            const isRevealed = revealedGifts?.includes(gift?.id);
            
            return (
              <motion.div
                key={gift?.id}
                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="relative group"
              >
                {/* Gift Card */}
                <div 
                  className={`relative bg-white rounded-3xl shadow-xl overflow-hidden cursor-pointer transition-all duration-500 ${
                    isRevealed ? 'transform-none' : 'hover:scale-105'
                  }`}
                  onClick={() => handleGiftReveal(gift?.id)}
                >
                  {/* Gift Image */}
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={gift?.image}
                      alt={gift?.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    
                    {/* Overlay */}
                    <div className={`absolute inset-0 bg-gradient-to-t ${gift?.color} opacity-80`}></div>
                    
                    {/* Gift Icon */}
                    <div className="absolute top-4 right-4 w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                      <Icon name={gift?.icon} size={24} color="white" />
                    </div>

                    {/* Reveal Overlay */}
                    {!isRevealed && (
                      <motion.div
                        initial={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center"
                      >
                        <div className="text-center text-white">
                          <motion.div
                            animate={{ scale: [1, 1.1, 1] }}
                            transition={{ duration: 2, repeat: Infinity }}
                          >
                            <Icon name="Gift" size={48} />
                          </motion.div>
                          <p className="mt-2 font-semibold">{content?.[currentLanguage]?.revealText}</p>
                        </div>
                      </motion.div>
                    )}
                  </div>

                  {/* Gift Content */}
                  <motion.div
                    initial={{ height: isRevealed ? 'auto' : '120px' }}
                    animate={{ height: isRevealed ? 'auto' : '120px' }}
                    className="p-6 overflow-hidden"
                  >
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">{gift?.name}</h3>
                    <p className="text-gray-600 mb-4">{gift?.description}</p>
                    
                    {/* Gift Details - Only shown when revealed */}
                    {isRevealed && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                      >
                        {/* Value & Duration */}
                        <div className="flex justify-between items-center mb-4 p-3 bg-gray-50 rounded-xl">
                          <div>
                            <p className="text-sm text-gray-500">Value</p>
                            <p className="font-bold text-gray-800">{gift?.value}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Duration</p>
                            <p className="font-bold text-gray-800">{gift?.duration}</p>
                          </div>
                        </div>

                        {/* Features */}
                        <div className="mb-4">
                          <p className="font-semibold text-gray-800 mb-2">Features:</p>
                          <div className="grid grid-cols-2 gap-2">
                            {gift?.features?.map((feature, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                                <Icon name="Check" size={16} className="text-green-500" />
                                <span>{feature}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Personal Message */}
                        <div className={`p-4 rounded-xl bg-gradient-to-r ${gift?.color} text-white`}>
                          <p className="text-sm font-medium leading-relaxed">
                            {gift?.personalMessage}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </motion.div>

                  {/* Sparkle Effects for Revealed Gifts */}
                  {isRevealed && (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                        className="absolute -top-2 -right-2 text-yellow-400"
                      >
                        <Icon name="Sparkles" size={24} />
                      </motion.div>
                      <motion.div
                        animate={{ rotate: -360 }}
                        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                        className="absolute -bottom-2 -left-2 text-pink-400"
                      >
                        <Icon name="Sparkles" size={20} />
                      </motion.div>
                    </>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* All Gifts Revealed Message */}
        {revealedGifts?.length === content?.[currentLanguage]?.gifts?.length && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mt-16 text-center"
          >
            <div className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-3xl p-8 text-white relative overflow-hidden">
              <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
              <div className="relative z-10">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="mb-4"
                >
                  <Icon name="Heart" size={48} className="mx-auto" />
                </motion.div>
                <h3 className="text-2xl md:text-3xl font-bold mb-4">
                  All Your Gifts Are Revealed! 🎉
                </h3>
                <p className="text-lg opacity-90 max-w-2xl mx-auto">
                  These are just small tokens of my love and appreciation for everything you are and everything you've achieved. You deserve the world, and I'll keep trying to give it to you, one gift at a time.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default GiftsShowcase;