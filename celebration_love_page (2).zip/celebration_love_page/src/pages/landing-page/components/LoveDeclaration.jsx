import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const LoveDeclaration = ({ currentLanguage }) => {
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [showHearts, setShowHearts] = useState(false);

  const content = {
    en: {
      title: "My Heart Speaks to Yours",
      subtitle: "Words that come straight from my soul",
      messages: [
        "You are my greatest achievement, my proudest moment, and my endless source of joy.",
        "Your success is our success, your dreams are our dreams, your happiness is my purpose.",
        "In a world full of numbers and rankings, you'll always be my number one.",
        "Your 3rd position shows the world your brilliance, but I've known it all along.",
        "Every day with you feels like winning the lottery of love.",
        "You inspire me to be better, to love deeper, to dream bigger.",
        "Our love story is my favorite book, and we're still writing the best chapters."
      ],
      emotions: [
        { icon: "Heart", label: "Endless Love", color: "text-red-500" },
        { icon: "Star", label: "Admiration", color: "text-yellow-500" },
        { icon: "Trophy", label: "Pride", color: "text-orange-500" },
        { icon: "Smile", label: "Joy", color: "text-pink-500" },
        { icon: "Infinity", label: "Forever", color: "text-purple-500" },
        { icon: "Sun", label: "Happiness", color: "text-amber-500" }
      ],
      finalMessage: "You are loved beyond measure, celebrated beyond words, and cherished beyond time. ❤️"
    },
    hi: {
      title: "मेरा दिल आपसे कहता है",
      subtitle: "वे शब्द जो सीधे मेरी आत्मा से आते हैं",
      messages: [
        "आप मेरी सबसे बड़ी उपलब्धि हैं, मेरा सबसे गर्व का पल हैं, और मेरी अनंत खुशी का स्रोत हैं।",
        "आपकी सफलता हमारी सफलता है, आपके सपने हमारे सपने हैं, आपकी खुशी मेरा उद्देश्य है।",
        "संख्याओं और रैंकिंग से भरी दुनिया में, आप हमेशा मेरे लिए नंबर वन रहेंगी।",
        "आपकी तीसरी स्थिति दुनिया को आपकी प्रतिभा दिखाती है, लेकिन मैं इसे हमेशा से जानता था।",
        "आपके साथ हर दिन प्रेम की लॉटरी जीतने जैसा लगता है।",
        "आप मुझे बेहतर बनने, गहरा प्रेम करने, बड़े सपने देखने की प्रेरणा देते हैं।",
        "हमारी प्रेम कहानी मेरी पसंदीदा किताब है, और हम अभी भी सबसे अच्छे अध्याय लिख रहे हैं।"
      ],
      emotions: [
        { icon: "Heart", label: "अनंत प्रेम", color: "text-red-500" },
        { icon: "Star", label: "प्रशंसा", color: "text-yellow-500" },
        { icon: "Trophy", label: "गर्व", color: "text-orange-500" },
        { icon: "Smile", label: "खुशी", color: "text-pink-500" },
        { icon: "Infinity", label: "हमेशा के लिए", color: "text-purple-500" },
        { icon: "Sun", label: "प्रसन्नता", color: "text-amber-500" }
      ],
      finalMessage: "आप बेहद प्यार किए जाते हैं, शब्दों से कहीं ज्यादा मनाए जाते हैं, और समय से भी ज्यादा संजोए जाते हैं। ❤️"
    },
    fil: {
      title: "Ang Aking Puso ay Nagsasalita sa Inyo",
      subtitle: "Mga salitang direktang nanggagaling sa aking kaluluwa",
      messages: [
        "Kayo ang aking pinakamalaking tagumpay, ang aking pinakamataas na karangalan, at ang aking walang hanggang kasiyahan.",
        "Ang inyong tagumpay ay aming tagumpay, ang inyong mga pangarap ay aming mga pangarap, ang inyong kaligayahan ay aking layunin.",
        "Sa mundong puno ng mga numero at ranking, lagi kayong magiging number one sa akin.",
        "Ang inyong 3rd position ay nagpapakita sa mundo ng inyong talino, pero alam ko na ito simula pa lang.",
        "Bawat araw kasama ninyo ay parang nanalo sa lottery ng pagmamahal.",
        "Kayo ang nag-inspire sa akin na maging mas mabuti, magmahal nang mas malalim, mangarap nang mas malaki.",
        "Ang aming love story ay aking paboritong libro, at patuloy pa nating sinusulat ang pinakamagagandang kabanata."
      ],
      emotions: [
        { icon: "Heart", label: "Walang Hanggang Pagmamahal", color: "text-red-500" },
        { icon: "Star", label: "Paghanga", color: "text-yellow-500" },
        { icon: "Trophy", label: "Pagmamalaki", color: "text-orange-500" },
        { icon: "Smile", label: "Kaligayahan", color: "text-pink-500" },
        { icon: "Infinity", label: "Magpakailanman", color: "text-purple-500" },
        { icon: "Sun", label: "Kasiyahan", color: "text-amber-500" }
      ],
      finalMessage: "Kayo ay minamahal nang walang hanggan, ipinagdiriwang nang higit sa mga salita, at pinahahalagahan nang higit sa panahon. ❤️"
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessageIndex((prev) => 
        prev === content?.[currentLanguage]?.messages?.length - 1 ? 0 : prev + 1
      );
    }, 4000);

    return () => clearInterval(interval);
  }, [currentLanguage, content]);

  useEffect(() => {
    setShowHearts(true);
    const timer = setTimeout(() => setShowHearts(false), 3000);
    return () => clearTimeout(timer);
  }, [currentMessageIndex]);

  // Generate floating hearts
  const floatingHearts = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 20 + 10,
    delay: Math.random() * 2,
    duration: Math.random() * 3 + 2
  }));

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-rose-100 via-pink-100 to-purple-100 relative overflow-hidden">
      {/* Floating Hearts Background */}
      {showHearts && floatingHearts?.map((heart) => (
        <motion.div
          key={heart?.id}
          initial={{ opacity: 0, scale: 0, x: `${heart?.x}vw`, y: `${heart?.y}vh` }}
          animate={{ 
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
            y: `${heart?.y - 20}vh`
          }}
          transition={{
            duration: heart?.duration,
            delay: heart?.delay,
            ease: "easeOut"
          }}
          className="absolute pointer-events-none text-pink-300"
          style={{ fontSize: heart?.size }}
        >
          ❤️
        </motion.div>
      ))}
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4 font-accent">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {content?.[currentLanguage]?.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Love Message */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 relative overflow-hidden min-h-96 flex items-center"
            >
              {/* Background Pattern */}
              <div className="absolute inset-0 bg-gradient-to-br from-pink-50 to-purple-50 opacity-50"></div>
              
              {/* Decorative Hearts */}
              <motion.div
                animate={{ 
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute top-6 right-6 text-pink-200"
              >
                <Icon name="Heart" size={48} />
              </motion.div>

              <motion.div
                animate={{ 
                  rotate: [0, -15, 15, 0],
                  scale: [1, 1.2, 1]
                }}
                transition={{ 
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 2
                }}
                className="absolute bottom-6 left-6 text-purple-200"
              >
                <Icon name="Heart" size={40} />
              </motion.div>

              <div className="relative z-10 w-full">
                {/* Message Display */}
                <motion.div
                  key={currentMessageIndex}
                  initial={{ opacity: 0, y: 30, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -30, scale: 0.9 }}
                  transition={{ duration: 0.8 }}
                  className="text-center"
                >
                  <div className="mb-6">
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="inline-block text-6xl mb-4"
                    >
                      💕
                    </motion.div>
                  </div>
                  
                  <blockquote className="text-xl md:text-2xl font-medium text-gray-700 leading-relaxed italic">
                    "{content?.[currentLanguage]?.messages?.[currentMessageIndex]}"
                  </blockquote>
                </motion.div>

                {/* Message Navigation Dots */}
                <div className="flex justify-center gap-2 mt-8">
                  {content?.[currentLanguage]?.messages?.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentMessageIndex(index)}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentMessageIndex 
                          ? 'bg-pink-500 scale-125' :'bg-gray-300 hover:bg-gray-400'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Emotions Panel */}
          <div className="space-y-6">
            <motion.h3
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="text-2xl font-bold text-gray-800 text-center"
            >
              What I Feel for You
            </motion.h3>

            {content?.[currentLanguage]?.emotions?.map((emotion, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, x: 10 }}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-4 cursor-pointer"
              >
                <div className={`w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center ${emotion?.color}`}>
                  <Icon name={emotion?.icon} size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">{emotion?.label}</h4>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: "100%" }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className={`h-2 rounded-full bg-gradient-to-r ${
                        emotion?.color?.includes('red') ? 'from-red-400 to-red-600' :
                        emotion?.color?.includes('yellow') ? 'from-yellow-400 to-yellow-600' :
                        emotion?.color?.includes('orange') ? 'from-orange-400 to-orange-600' :
                        emotion?.color?.includes('pink') ? 'from-pink-400 to-pink-600' :
                        emotion?.color?.includes('purple') ? 'from-purple-400 to-purple-600' :
                        'from-amber-400 to-amber-600'
                      }`}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Final Love Declaration */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="bg-gradient-to-r from-pink-500 via-red-500 to-purple-500 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden">
            {/* Background Effects */}
            <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
            
            {/* Animated Hearts */}
            <motion.div
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute top-4 left-4 text-pink-200 opacity-60"
            >
              <Icon name="Heart" size={32} />
            </motion.div>

            <motion.div
              animate={{ 
                scale: [1, 1.2, 1],
                rotate: [0, -8, 8, 0]
              }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1
              }}
              className="absolute top-8 right-8 text-purple-200 opacity-60"
            >
              <Icon name="Heart" size={28} />
            </motion.div>

            <motion.div
              animate={{ 
                scale: [1, 1.4, 1],
                rotate: [0, 10, -10, 0]
              }}
              transition={{ 
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 2
              }}
              className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-red-200 opacity-60"
            >
              <Icon name="Heart" size={36} />
            </motion.div>

            <div className="relative z-10">
              <motion.div
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-6xl mb-6"
              >
                💖
              </motion.div>
              
              <p className="text-xl md:text-2xl font-bold leading-relaxed max-w-4xl mx-auto">
                {content?.[currentLanguage]?.finalMessage}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LoveDeclaration;