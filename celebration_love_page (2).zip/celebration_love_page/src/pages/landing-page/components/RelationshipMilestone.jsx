import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const RelationshipMilestone = ({ currentLanguage }) => {
  const [timeLeft, setTimeLeft] = useState({});
  const [currentTime, setCurrentTime] = useState(new Date());

  // Mock next monthsary date (next month from current date)
  const nextMonthsary = new Date();
  nextMonthsary?.setMonth(nextMonthsary?.getMonth() + 1);
  nextMonthsary?.setDate(28); // Assuming 28th is the monthsary date

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);
      const difference = nextMonthsary?.getTime() - now?.getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [nextMonthsary]);

  const content = {
    en: {
      title: "Our Love Journey Continues",
      subtitle: "Celebrating milestones and looking forward to forever",
      nextMonthsary: "Next Monthsary Countdown",
      currentMilestone: "Current Milestone",
      monthsCompleted: "Months Together",
      achievementsCelebrated: "Achievements Celebrated",
      memoriesCreated: "Beautiful Memories",
      promisesKept: "Promises Kept",
      futurePromise: "The Promise of \'Always Be 3'",
      futureMessage: `Just like how you achieved 3rd position through dedication and hard work, I promise that in our relationship, you'll always be my number 1, but we'll always celebrate being '3' together - you, me, and our love that makes us stronger.\n\nEvery achievement of yours becomes our shared victory, and every milestone we cross together makes our bond even more special.`,
      countdownLabels: {
        days: "Days",
        hours: "Hours", 
        minutes: "Minutes",
        seconds: "Seconds"
      },
      milestones: [
        { icon: "Heart", label: "First Meeting", value: "2024", color: "text-pink-500" },
        { icon: "Calendar", label: "Months Together", value: "24+", color: "text-purple-500" },
        { icon: "Trophy", label: "Your 3rd Position", value: "Recent", color: "text-yellow-500" },
        { icon: "Star", label: "Memories Made", value: "∞", color: "text-blue-500" }
      ]
    },
    hi: {
      title: "हमारी प्रेम यात्रा जारी है",
      subtitle: "मील के पत्थर मनाना और हमेशा के लिए आगे देखना",
      nextMonthsary: "अगली मासिक वर्षगांठ की उल्टी गिनती",
      currentMilestone: "वर्तमान मील का पत्थर",
      monthsCompleted: "साथ बिताए महीने",
      achievementsCelebrated: "मनाई गई उपलब्धियां",
      memoriesCreated: "खूबसूरत यादें",
      promisesKept: "निभाए गए वादे",
      futurePromise: "'हमेशा 3 रहने\' का वादा",
      futureMessage: `जिस तरह आपने समर्पण और कड़ी मेहनत से तीसरी स्थिति हासिल की है, मैं वादा करता हूं कि हमारे रिश्ते में आप हमेशा मेरे लिए नंबर 1 रहेंगी, लेकिन हम हमेशा एक साथ '3' होने का जश्न मनाएंगे - आप, मैं, और हमारा प्यार जो हमें मजबूत बनाता है।\n\nआपकी हर उपलब्धि हमारी साझा जीत बन जाती है, और हर मील का पत्थर जो हम एक साथ पार करते हैं, हमारे बंधन को और भी खास बना देता है।`,
      countdownLabels: {
        days: "दिन",
        hours: "घंटे",
        minutes: "मिनट",
        seconds: "सेकंड"
      },
      milestones: [
        { icon: "Heart", label: "पहली मुलाकात", value: "दिन 1", color: "text-pink-500" },
        { icon: "Calendar", label: "साथ बिताए महीने", value: "12+", color: "text-purple-500" },
        { icon: "Trophy", label: "आपकी तीसरी स्थिति", value: "हाल ही में", color: "text-yellow-500" },
        { icon: "Star", label: "बनाई गई यादें", value: "∞", color: "text-blue-500" }
      ]
    },
    fil: {
      title: "Ang Aming Love Journey ay Nagpapatuloy",
      subtitle: "Pagdiriwang ng mga milestone at pag-aasam sa forever",
      nextMonthsary: "Next Monthsary Countdown",
      currentMilestone: "Kasalukuyang Milestone",
      monthsCompleted: "Mga Buwan Nang Magkasama",
      achievementsCelebrated: "Mga Tagumpay na Ipinagdiwang",
      memoriesCreated: "Mga Magagandang Alaala",
      promisesKept: "Mga Natupad na Pangako",
      futurePromise: "Ang Pangako ng \'Always Be 3'",
      futureMessage: `Tulad ng kung paano ninyo nakamit ang 3rd position sa pamamagitan ng dedikasyon at sipag, pangako ko na sa aming relasyon, lagi kayong magiging number 1 sa akin, pero lagi nating ipagdiriwang ang pagiging '3' nang magkasama - kayo, ako, at ang aming pagmamahal na nagpapalakas sa amin.\n\nBawat tagumpay ninyo ay nagiging aming shared victory, at bawat milestone na aming natatawid nang magkasama ay nagiging mas espesyal ang aming bond.`,
      countdownLabels: {
        days: "Mga Araw",
        hours: "Mga Oras",
        minutes: "Mga Minuto", 
        seconds: "Mga Segundo"
      },
      milestones: [
        { icon: "Heart", label: "Unang Pagkikita", value: "Araw 1", color: "text-pink-500" },
        { icon: "Calendar", label: "Mga Buwan Nang Magkasama", value: "12+", color: "text-purple-500" },
        { icon: "Trophy", label: "Inyong 3rd Position", value: "Kamakailan", color: "text-yellow-500" },
        { icon: "Star", label: "Mga Nalikha na Alaala", value: "∞", color: "text-blue-500" }
      ]
    }
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-800 mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {content?.[currentLanguage]?.subtitle}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Countdown Timer */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-3xl shadow-2xl p-8 relative overflow-hidden"
          >
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-gradient-to-br from-pink-100 to-purple-100 opacity-50"></div>
            
            <div className="relative z-10">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  {content?.[currentLanguage]?.nextMonthsary}
                </h3>
                <p className="text-gray-600">
                  {nextMonthsary?.toLocaleDateString(currentLanguage === 'hi' ? 'hi-IN' : currentLanguage === 'fil' ? 'fil-PH' : 'en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>

              {/* Countdown Display */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(timeLeft)?.map(([unit, value], index) => (
                  <motion.div
                    key={unit}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="text-center"
                  >
                    <div className="bg-gradient-to-br from-pink-500 to-purple-500 rounded-2xl p-4 mb-2 shadow-lg">
                      <motion.div
                        key={value}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                        transition={{ duration: 0.3 }}
                        className="text-2xl md:text-3xl font-bold text-white"
                      >
                        {value || 0}
                      </motion.div>
                    </div>
                    <p className="text-sm font-semibold text-gray-600 capitalize">
                      {content?.[currentLanguage]?.countdownLabels?.[unit]}
                    </p>
                  </motion.div>
                ))}
              </div>

              {/* Floating Hearts */}
              <motion.div
                animate={{ 
                  y: [0, -10, 0],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute top-6 right-6 text-pink-300"
              >
                <Icon name="Heart" size={32} />
              </motion.div>
            </div>
          </motion.div>

          {/* Current Milestones */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-bold text-gray-800 mb-6">
              {content?.[currentLanguage]?.currentMilestone}
            </h3>

            {content?.[currentLanguage]?.milestones?.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.02, x: 10 }}
                className="bg-white rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center gap-4"
              >
                <div className={`w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center ${milestone?.color}`}>
                  <Icon name={milestone?.icon} size={28} />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-gray-800 text-lg">{milestone?.label}</h4>
                  <p className="text-2xl font-bold text-gray-600">{milestone?.value}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Future Promise Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden"
        >
          {/* Background Effects */}
          <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -translate-y-20 translate-x-20"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-16 -translate-x-16"></div>

          <div className="relative z-10">
            <div className="text-center mb-8">
              <motion.div
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="inline-block mb-4"
              >
                <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-4xl font-bold">3</span>
                </div>
              </motion.div>
              <h3 className="text-3xl md:text-4xl font-bold mb-4">
                {content?.[currentLanguage]?.futurePromise}
              </h3>
            </div>

            <div className="max-w-4xl mx-auto">
              <p className="text-lg md:text-xl leading-relaxed whitespace-pre-line text-center opacity-95">
                {content?.[currentLanguage]?.futureMessage}
              </p>
            </div>

            {/* Decorative Elements */}
            <div className="flex justify-center items-center gap-8 mt-8">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0 }}
              >
                <Icon name="Heart" size={32} className="text-pink-200" />
              </motion.div>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
              >
                <Icon name="Infinity" size={36} className="text-purple-200" />
              </motion.div>
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity, delay: 1 }}
              >
                <Icon name="Heart" size={32} className="text-pink-200" />
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default RelationshipMilestone;