import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const HeroSection = ({ currentLanguage, onLanguageChange }) => {
  const [showTypewriter, setShowTypewriter] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowTypewriter(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const content = {
    en: {
      congratulations: "Congratulations on Your Amazing 3rd Position!",
      subtitle: "Your dedication and hard work have paid off beautifully",
      romantic: "From someone who believes in you completely ❤️"
    },
    hi: {
      congratulations: "आपकी शानदार तीसरी स्थिति पर बधाई!",
      subtitle: "आपकी मेहनत और लगन का फल मिला है",
      romantic: "किसी ऐसे व्यक्ति की ओर से जो आप पर पूरा भरोसा करता है ❤️"
    },
    fil: {
      congratulations: "Congratulations sa Inyong Amazing 3rd Position!",
      subtitle: "Ang inyong sipag at tiyaga ay nagbunga",
      romantic: "Mula sa taong naniniwala sa inyo nang lubos ❤️"
    }
  };

  const languages = [
  { code: 'en', name: 'English', hint: 'The language of our first conversation' },
  { code: 'hi', name: 'हिंदी', hint: 'भाषा जो आपके दिल के करीब है' },
  { code: 'fil', name: 'Filipino', hint: 'Ang wika ng inyong puso' }];


  // Confetti particles
  const confettiParticles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    color: ['#FF6B9D', '#C8A8E9', '#FFD700', '#4ECDC4', '#FF8A80']?.[Math.floor(Math.random() * 5)],
    size: Math.random() * 8 + 4,
    delay: Math.random() * 2
  }));

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-yellow-50 overflow-hidden">
      {/* Animated Background Confetti */}
      {confettiParticles?.map((particle) =>
      <motion.div
        key={particle?.id}
        className="absolute rounded-full opacity-70"
        style={{
          left: `${particle?.x}%`,
          top: `${particle?.y}%`,
          width: particle?.size,
          height: particle?.size,
          backgroundColor: particle?.color
        }}
        animate={{
          y: [0, -20, 0],
          rotate: [0, 360],
          scale: [1, 1.2, 1]
        }}
        transition={{
          duration: 3,
          delay: particle?.delay,
          repeat: Infinity,
          ease: "easeInOut"
        }} />

      )}
      {/* Language Dropdown */}
      <div className="absolute top-6 right-6 z-20">
        <div className="relative group">
          <button className="flex items-center gap-2 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
            <Icon name="Globe" size={18} />
            <span className="font-medium text-gray-700">
              {languages?.find((lang) => lang?.code === currentLanguage)?.name}
            </span>
            <Icon name="ChevronDown" size={16} />
          </button>
          
          <div className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 min-w-64">
            {languages?.map((lang) =>
            <button
              key={lang?.code}
              onClick={() => onLanguageChange(lang?.code)}
              className={`w-full text-left px-4 py-3 hover:bg-pink-50 transition-colors ${
              currentLanguage === lang?.code ? 'bg-pink-100 text-pink-700' : 'text-gray-700'}`
              }>

                <div className="font-medium">{lang?.name}</div>
                <div className="text-xs text-gray-500 mt-1">{lang?.hint}</div>
              </button>
            )}
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="relative z-10 flex items-center justify-center min-h-screen px-6">
        <div className="text-center max-w-4xl">
          {/* Animated Trophy Icon */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 1, ease: "backOut" }}
            className="mb-8">

            <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full shadow-2xl">
              <Icon name="Trophy" size={48} color="white" />
            </div>
          </motion.div>

          {/* Main Headline with Typewriter Effect */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-4xl md:text-6xl font-bold text-gray-800 mb-6 leading-tight">

            {showTypewriter &&
            <motion.span
              initial={{ width: 0 }}
              animate={{ width: "100%" }}
              transition={{ duration: 2, ease: "easeInOut" }}
              className="inline-block overflow-hidden whitespace-nowrap text-[106px]">

                {content?.[currentLanguage]?.congratulations}
              </motion.span>
            }
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.5 }}
            className="text-xl md:text-2xl text-gray-600 mb-4 font-medium">

            {content?.[currentLanguage]?.subtitle}
          </motion.p>

          {/* Romantic Message */}
          <motion.p
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 2 }}
            className="text-lg text-pink-600 font-accent font-semibold">

            {content?.[currentLanguage]?.romantic}
          </motion.p>

          {/* Sparkle Effects */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute -top-10 -right-10 text-yellow-400">

            <Icon name="Sparkles" size={32} />
          </motion.div>
          
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className="absolute -bottom-10 -left-10 text-pink-400">

            <Icon name="Sparkles" size={28} />
          </motion.div>
        </div>
      </div>
      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2">

        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center text-gray-500">

          <span className="text-sm mb-2">Scroll for more surprises</span>
          <Icon name="ChevronDown" size={24} />
        </motion.div>
      </motion.div>
    </div>);

};

export default HeroSection;