import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const PromoCodeSection = ({ currentLanguage }) => {
  const [copiedCodes, setCopiedCodes] = useState([]);
  const [showToast, setShowToast] = useState(null);

  const content = {
    en: {
      title: "Your Exclusive Access Codes",
      subtitle: "Premium subscriptions activated with love",
      copyText: "Copy Code",
      copiedText: "Copied!",
      shareText: "Share with Friends",
      instructions: "Tap any code to copy it to your clipboard, then use it to activate your premium subscription",
      codes: [
      {
        id: 'netflix',
        service: 'Netflix Premium',
        code: 'https://net2025.cc/home',
        description: 'Redeem for 999 months of Netflix Premium OR Contact Hubby',
        color: 'from-red-500 to-red-600',
        icon: 'Play'
      },
      {
        id: 'spotify',
        service: 'Spotify Premium',
        code: 'Email: proaheremiscalleneous@duck.com Pass: 1234qwer@$#LOYALFOREVER',
        description: 'Redeem for 04 months of Spotify Premium',
        color: 'from-green-500 to-green-600',
        icon: 'Music'
      },
      {
        id: 'MUBI',
        service: 'MUBI Prmium',
        code: 'Web: https://mubi.com/en/timesprime2025 Promo: HAQEH2',
        description: 'Redeem for 03 months of MUBI Premium',
        color: 'from-blue-500 to-purple-600',
        icon: 'Star'
      }],

      toast: {
        success: "Code copied to clipboard!",
        error: "Failed to copy code"
      }
    },
    hi: {
      title: "आपके विशेष एक्सेस कोड",
      subtitle: "प्रीमियम सब्सक्रिप्शन प्यार के साथ सक्रिय",
      copyText: "कोड कॉपी करें",
      copiedText: "कॉपी हो गया!",
      shareText: "दोस्तों के साथ शेयर करें",
      instructions: "किसी भी कोड को टैप करें और इसे अपने क्लिपबोर्ड में कॉपी करें, फिर इसका उपयोग करके अपनी प्रीमियम सब्सक्रिप्शन सक्रिय करें",
      codes: [
      {
        id: 'netflix',
        service: 'Netflix Premium',
        code: 'LOVE3RDPOS2025',
        description: '6 महीने के Netflix Premium के लिए रिडीम करें',
        color: 'from-red-500 to-red-600',
        icon: 'Play'
      },
      {
        id: 'spotify',
        service: 'Spotify Premium',
        code: 'MUSIC4LOVE2025',
        description: '12 महीने के Spotify Premium के लिए रिडीम करें',
        color: 'from-green-500 to-green-600',
        icon: 'Music'
      },
      {
        id: 'disney',
        service: 'Disney+ Premium',
        code: 'MAGIC3RD2025',
        description: '12 महीने के Disney+ Premium के लिए रिडीम करें',
        color: 'from-blue-500 to-purple-600',
        icon: 'Star'
      }],

      toast: {
        success: "कोड क्लिपबोर्ड में कॉपी हो गया!",
        error: "कोड कॉपी करने में विफल"
      }
    },
    fil: {
      title: "Ang Inyong Exclusive Access Codes",
      subtitle: "Premium subscriptions na na-activate with love",
      copyText: "Copy Code",
      copiedText: "Na-copy na!",
      shareText: "I-share sa mga Kaibigan",
      instructions: "I-tap ang kahit anong code para ma-copy sa clipboard, tapos gamitin ito para ma-activate ang premium subscription",
      codes: [
      {
        id: 'netflix',
        service: 'Netflix Premium',
        code: 'LOVE3RDPOS2025',
        description: 'I-redeem para sa 6 months ng Netflix Premium',
        color: 'from-red-500 to-red-600',
        icon: 'Play'
      },
      {
        id: 'spotify',
        service: 'Spotify Premium',
        code: 'MUSIC4LOVE2025',
        description: 'I-redeem para sa 12 months ng Spotify Premium',
        color: 'from-green-500 to-green-600',
        icon: 'Music'
      },
      {
        id: 'disney',
        service: 'Disney+ Premium',
        code: 'MAGIC3RD2025',
        description: 'I-redeem para sa 12 months ng Disney+ Premium',
        color: 'from-blue-500 to-purple-600',
        icon: 'Star'
      }],

      toast: {
        success: "Na-copy na ang code sa clipboard!",
        error: "Hindi na-copy ang code"
      }
    }
  };

  const copyToClipboard = async (code, codeId) => {
    try {
      await navigator.clipboard?.writeText(code);
      setCopiedCodes([...copiedCodes, codeId]);
      setShowToast({ type: 'success', message: content?.[currentLanguage]?.toast?.success });

      // Simulate haptic feedback on mobile
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }

      setTimeout(() => {
        setCopiedCodes(copiedCodes?.filter((id) => id !== codeId));
      }, 3000);
    } catch (err) {
      setShowToast({ type: 'error', message: content?.[currentLanguage]?.toast?.error });
    }

    setTimeout(() => setShowToast(null), 3000);
  };

  const shareCode = async (code, service) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${service} Premium Code`,
          text: `Check out this premium code: ${code}`,
          url: window.location?.href
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback to copying URL
      copyToClipboard(`${service} Code: ${code} - ${window.location?.href}`, 'share');
    }
  };

  return (
    <div className="py-20 px-6 bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-40 h-40 bg-pink-300 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-purple-300 rounded-full blur-3xl"></div>
      </div>
      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16">

          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            {content?.[currentLanguage]?.title}
          </h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto mb-8">
            {content?.[currentLanguage]?.subtitle}
          </p>
          
          {/* Instructions */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Icon name="Info" size={24} className="text-blue-300" />
              <span className="font-semibold">How to Use</span>
            </div>
            <p className="opacity-90 leading-relaxed">
              {content?.[currentLanguage]?.instructions}
            </p>
          </div>
        </motion.div>

        {/* Promo Codes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content?.[currentLanguage]?.codes?.map((item, index) => {
            const isCopied = copiedCodes?.includes(item?.id);

            return (
              <motion.div
                key={item?.id}
                initial={{ opacity: 0, y: 50, rotateY: -15 }}
                whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.02, rotateY: 5 }}
                className="relative group perspective-1000">

                {/* Code Card */}
                <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-6 border border-white/20 hover:border-white/40 transition-all duration-300 relative overflow-hidden">
                  {/* Background Gradient */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${item?.color} opacity-20 rounded-3xl`}></div>
                  
                  {/* Content */}
                  <div className="relative z-10">
                    {/* Service Header */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 bg-gradient-to-br ${item?.color} rounded-full flex items-center justify-center`}>
                          <Icon name={item?.icon} size={24} color="white" />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg">{item?.service}</h3>
                          <p className="text-sm opacity-70">Premium Access</p>
                        </div>
                      </div>
                      
                      {/* Security Badge */}
                      <div className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
                        <Icon name="Shield" size={12} />
                        Verified
                      </div>
                    </div>

                    {/* Promo Code */}
                    <div className="mb-6">
                      <p className="text-sm opacity-70 mb-2">Promo Code:</p>
                      <motion.div
                        whileTap={{ scale: 0.98 }}
                        onClick={() => copyToClipboard(item?.code, item?.id)}
                        className="bg-black/30 rounded-xl p-4 cursor-pointer hover:bg-black/40 transition-all duration-300 border-2 border-dashed border-white/30 hover:border-white/50">

                        <div className="flex items-center justify-between">
                          <code className="text-xl font-mono font-bold tracking-wider">
                            {item?.code}
                          </code>
                          <motion.div
                            animate={isCopied ? { scale: [1, 1.2, 1] } : {}}
                            className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-semibold transition-all duration-300 ${
                            isCopied ?
                            'bg-green-500 text-white' : 'bg-white/20 text-white hover:bg-white/30'}`
                            }>

                            <Icon name={isCopied ? "Check" : "Copy"} size={16} />
                            <span>{isCopied ? content?.[currentLanguage]?.copiedText : content?.[currentLanguage]?.copyText}</span>
                          </motion.div>
                        </div>
                      </motion.div>
                    </div>

                    {/* Description */}
                    <p className="text-sm opacity-80 mb-6 leading-relaxed">
                      {item?.description}
                    </p>

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <button
                        onClick={() => copyToClipboard(item?.code, item?.id)}
                        className={`flex-1 py-3 px-4 rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
                        isCopied ?
                        'bg-green-500 text-white' :
                        `bg-gradient-to-r ${item?.color} hover:shadow-lg hover:shadow-black/25`}`
                        }>

                        <Icon name={isCopied ? "Check" : "Copy"} size={18} />
                        {isCopied ? content?.[currentLanguage]?.copiedText : content?.[currentLanguage]?.copyText}
                      </button>
                      
                      <button
                        onClick={() => shareCode(item?.code, item?.service)}
                        className="px-4 py-3 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300 flex items-center justify-center">

                        <Icon name="Share2" size={18} />
                      </button>
                    </div>
                  </div>

                  {/* Sparkle Effects */}
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="absolute -top-2 -right-2 text-yellow-300 opacity-60">

                    <Icon name="Sparkles" size={20} />
                  </motion.div>
                </div>
              </motion.div>);

          })}
        </div>

        {/* Success Message */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 text-center">

          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 max-w-4xl mx-auto">
            <motion.div
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="mb-4">

              <Icon name="Heart" size={48} className="mx-auto text-pink-300" />
            </motion.div>
            <h3 className="text-2xl font-bold mb-4">
              Enjoy Your Premium Experience! 💝
            </h3>
            <p className="opacity-90 leading-relaxed max-w-2xl mx-auto">
              These codes are my way of saying thank you for being amazing and achieving so much. 
              Use them whenever you want to enjoy some premium entertainment. You've earned it!
            </p>
          </div>
        </motion.div>
      </div>
      {/* Toast Notification */}
      {showToast &&
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.9 }}
        className={`fixed bottom-6 right-6 z-50 px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 ${
        showToast?.type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`
        }>

          <Icon name={showToast?.type === 'success' ? "Check" : "X"} size={20} />
          <span className="font-semibold">{showToast?.message}</span>
        </motion.div>
      }
    </div>);

};

export default PromoCodeSection;